# COLE NO AUDITOR-ESTRUTURA (janela dele)

```text
# COMO EXECUTAR v1.10 — AVALIAÇÃO TERRITORIAL DA MINUTA

Data: 2026-09-25
Origem: operador

O Comentador liberou a minuta v1.10 para as duas janelas
(TRILHA101 12/12; sem reabrir D1; sem alterar N1/N2; sem ampliar
o escopo do COMO EXECUTAR).

Anexos:
- 4º COMO EXECUTAR — v1.10 (MINUTA).md
- COMENTADOR_LIBERA_V110_JANELAS_2026-09-25.md
- TRILHA101_minuta_v110_2026-09-25.json
- (bases para consulta: contrato 841532da · schema v1.3 28cbc9c7)

No seu território, avalie:
1. coerência da minuta com o Contrato de Saída vigente (§8 portões,
   falha dura sem direção, materialização passo separado);
2. referências ao Schema-Claim v1.3 e às digitais — corretas?
3. as 4 decisões do fechamento batem com o que o materializador
   espera (P-K1/P-K2/V-K6)?
4. alguma frase da minuta contradiz N1/N2 ou o contrato vigente?

Responda: subscrevo sem ressalva · subscrevo com ressalva(s) · não subscrevo.
```
