# PACOTE DE AUDITORIA — B1 (V7c) — 2026-09-13

**Para:** Auditor-Mestre (rodada 5 — condição única: pacote da V7 no mesmo formato do V6 verificado)
e 2º auditor externo (estrutura).
**Canônica:** `canonica/B1 NEUROINFLAMAÇÃO V7 CANONICA.md`
**sha256 da canônica:** `6e2c29797e6322f16dcc5248cce552be613dd11f1de957c66aaa913e69225238` (idêntico ao da V7 entregue na carta 3 — a canônica NÃO foi tocada nesta rodada).

## O que mudou em relação ao pacote V6 que o mestre auditou
1. **A canônica é a V7 de verdade** (C4 decidida no algoritmo; AUD-066; AUD-067 Mehta; L717; trilhas 21–22).
2. **Manifesto 2.9** (era 2.8 com rótulo V5 — a V-16 proposta pelo mestre mediu e pegou): artefato_rotulo→V7,
   refs_01_pmids_base→201, motivo do PROVISÓRIO amarrado à fila P-6 (108 vínculos/91 refs). Canônica intacta.
3. **Trilha 24** (réplica do parecer nº 4, na V7): V-16 + tokens ambíguos por camada + 3 tokens temáticos.
4. **decisoes_B1.md rev.8** (confissão do erro de ENTREGA, réplica, fronteiras).
5. **gate_script.py rev.A2** (rodada com o auditor de estrutura; backup do oficial no workspace).

## Como reproduzir (layout da biblioteca)
```
mkdir -p B1 && cd B1
# copie: canonica/*.md   -> ./B1 NEUROINFLAMAÇÃO V7 CANONICA.md
#        Evidencias/     -> ./Evidencias/
#        Auditoria_B1/   -> ./Auditoria_B1/
#        producao/       -> ./producao/
python3 ferramentas/gate_script.py .
python3 ferramentas/validar_auditoria.py . --biblioteca "B1 NEUROINFLAMAÇÃO V7 CANONICA.md" --ledger Auditoria_B1/ledger_auditoria_B1.json
```
Saídas de referência em `saidas/` (geradas 2026-09-13, todas exit=0):
gate rev.A2 APROVADO · checklist 41/41 (na máquina da casa) · framework 0 ERRO/236 AVISO · P-8 0 ERRO/26 AVISO ·
trilha 24: V-16 OK (4 superfícies).

## Íntegro
`sha256sum -c SHA256SUMS.txt` — todos os arquivos exceto este README e o próprio SHA256SUMS.
